package oo.Calculator;

public interface Token<T> {
    int process();
}
