package oo.Calculator;

public class Divide extends Operator<Integer>{
    public Divide(int n) {
        super(n);
    }

    @Override 
    public int process() {
        return 0;
    }
}
