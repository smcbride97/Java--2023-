package oo.Calculator;

import java.util.List;
import java.util.ArrayList;

public abstract class Operator<T> implements Token<T> {
    private int n; // number of operands for this operator
    protected List<T> operands;

    Operator(int n) {
        this.n = n;
        this.operands = new ArrayList();
    }
    
}
