package oo.Calculator;

public class Multiply extends Operator<Integer>{
    public Multiply(int n) {
        super(n);
    }

    @Override 
    public int process() {
        return 0;
    }
}
