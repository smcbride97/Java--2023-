package oo.Calculator;

public class Negation extends Operator<Integer>{
    public Negation(int n) {
        super(n);
    }

    @Override 
    public int process() {
        return 0;
    }
}
