package oo.Calculator;

public class Remainder extends Operator<Integer>{
    public Remainder(int n) {
        super(n);
    }

    @Override 
    public int process() {
        return 0;
    }
}
