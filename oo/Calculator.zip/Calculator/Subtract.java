package oo.Calculator;

public class Subtract extends Operator<Integer> {
    public Subtract(int n) {
        super(n);
    }

    @Override 
    public int process() {
        return 0;
    }
}
