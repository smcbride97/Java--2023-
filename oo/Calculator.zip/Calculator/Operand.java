package oo.Calculator;

public class Operand<T> implements Token<T> {
    private int value;

    public Operand(int value) {
        this.value = value;
    }

    @Override
    public int process() {
        return this.value;
    }
}
