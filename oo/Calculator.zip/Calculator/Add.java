package oo.Calculator;

public class Add extends Operator<Integer> {
    public Add(int n) {
        super(n);
    }

    @Override 
    public int process() {
        return 0;
    }
}
